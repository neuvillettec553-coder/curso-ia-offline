# Agente de IA (custo zero) - v2.0

App web instalavel (PWA) para Android. Agente codador com loop Observar -> Raciocinar -> Agir, ferramentas, tarefas persistentes, editor de contexto e fallback automatico entre Gemini, Groq e OpenRouter.

## Telas
- **Tarefas**: lista persistente de tudo que foi executado, com status, duracao, tokens e arquivos gerados.
- **Detalhe da tarefa**: o log completo do loop (Observar / Raciocinar / Agir) mais o campo para nova tarefa.
- **Contexto**: edita agentes.md, memory.md, skills.md e os arquivos criados pelo agente em agent-output/. Renomeia, baixa em ZIP e envia ao GitHub.
- **Playground**: testa as APIs (latencia e tokens reais) e roda JavaScript em sandbox.
- **Config**: chaves de API, modelos, token do GitHub, limite de passos e acoes de manutencao.

## Nada se perde
- Tarefas, passos e arquivos ficam no armazenamento do aparelho entre sessoes.
- A aba Config tem backup completo (JSON) e restauracao, alem do ZIP dos arquivos.
- Envio dos arquivos direto ao repositorio pelo token do GitHub.

## Publicacao automatica
Todo push na branch main compila e publica no GitHub Pages (workflow em .github/workflows/deploy.yml).
Configuracao unica: Settings > Pages > Source = GitHub Actions.

## Rodar localmente (opcional, Termux ou PC)
    npm install
    npm run dev

## Privacidade
Chaves, tarefas e arquivos ficam no localStorage do navegador do aparelho. Nada e enviado a servidores proprios; as chamadas vao direto aos provedores de IA.
