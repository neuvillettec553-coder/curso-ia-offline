import { zipSync, strToU8 } from 'fflate';
import { DEFAULTS } from './defaults';

// Sistema de arquivos virtual no localStorage (limite do navegador: ~5 MB no total).
const P = 'vfs:file:';
const INDEX = 'vfs:index';
export const CORE = ['agentes.md', 'memory.md', 'skills.md'];
export const PROJECT_ROOT = 'agent-output';

export function normalize(path: string): string {
  const p = String(path).replace(/\\/g, '/').replace(/^\/+/, '').trim();
  if (!p || p.split('/').some((s) => s === '..' || s === '')) throw new Error('Caminho invalido: ' + path);
  return p;
}

// Fonte da verdade do caminho: se o modelo nao usar a pasta do projeto, ela e aplicada aqui.
export function sanitizePath(path: string): string {
  const p = normalize(path);
  if (CORE.includes(p)) return p;
  if (p === PROJECT_ROOT || p.startsWith(PROJECT_ROOT + '/')) return p;
  return PROJECT_ROOT + '/' + p.replace(/^\.\//, '');
}

function getIndex(): string[] {
  try {
    return JSON.parse(localStorage.getItem(INDEX) || '[]');
  } catch {
    return [];
  }
}

function setIndex(idx: string[]) {
  localStorage.setItem(INDEX, JSON.stringify(idx));
}

// Remove registros corrompidos ('undefined', vazios) gravados por versoes anteriores.
export function cleanupIndex() {
  const idx = getIndex();
  const keep: string[] = [];
  for (const f of idx) {
    if (typeof f !== 'string' || f.trim() === '' || f === 'undefined' || f === 'null') {
      localStorage.removeItem(P + f);
      continue;
    }
    const v = localStorage.getItem(P + f);
    if (v === null || v.trim() === '') {
      localStorage.removeItem(P + f);
      continue;
    }
    keep.push(f);
  }
  setIndex(keep);
  localStorage.removeItem(P + 'undefined');
  localStorage.removeItem(P + 'null');
  return keep;
}

export function ensureSeed() {
  for (const name of CORE) {
    if (localStorage.getItem(P + name) === null) localStorage.setItem(P + name, DEFAULTS[name]);
  }
  cleanupIndex();
}

export function listFiles(): string[] {
  ensureSeed();
  const idx = cleanupIndex().filter((f) => !CORE.includes(f));
  return [...CORE, ...idx.sort()];
}

export function readFile(path: string): string {
  const p = normalize(path);
  ensureSeed();
  const v = localStorage.getItem(P + p);
  if (v === null) throw new Error('Arquivo nao encontrado: ' + p);
  return v;
}

export function writeFile(path: string, content: string) {
  const p = sanitizePath(path);
  localStorage.setItem(P + p, content);
  const idx = getIndex();
  if (!CORE.includes(p) && !idx.includes(p)) setIndex([...idx, p]);
}

export function renameFile(from: string, to: string) {
  const a = normalize(from);
  const b = sanitizePath(to);
  const v = readFile(a);
  writeFile(b, v);
  if (a !== b) deleteFile(a);
}

export function deleteFile(path: string) {
  const p = normalize(path);
  if (CORE.includes(p)) throw new Error('Arquivos centrais nao podem ser apagados.');
  localStorage.removeItem(P + p);
  setIndex(getIndex().filter((f) => f !== p));
}

export function restoreDefault(name: string): string {
  if (!DEFAULTS[name]) throw new Error('Sem modelo padrao para ' + name);
  writeFile(name, DEFAULTS[name]);
  return DEFAULTS[name];
}

export function allFiles(): Record<string, string> {
  const out: Record<string, string> = {};
  for (const f of listFiles()) out[f] = readFile(f);
  return out;
}

// Agrupa por pasta, para a interface mostrar os caminhos completos.
export function groupByFolder(): { folder: string; names: string[] }[] {
  const map = new Map<string, string[]>();
  for (const f of listFiles()) {
    const i = f.lastIndexOf('/');
    const folder = i < 0 ? '(raiz)' : f.slice(0, i);
    map.set(folder, [...(map.get(folder) ?? []), f]);
  }
  return [...map.entries()].map(([folder, names]) => ({ folder, names })).sort((a, b) => a.folder.localeCompare(b.folder));
}

export function buildZip(): Uint8Array {
  const data: Record<string, Uint8Array> = {};
  for (const [name, content] of Object.entries(allFiles())) {
    const path = CORE.includes(name) ? 'context-files/' + name : name;
    data[path] = strToU8(content);
  }
  return zipSync(data);
}

export function downloadBlob(data: string | Uint8Array, filename: string, mime: string) {
  const blob = typeof data === 'string' ? new Blob([data], { type: mime }) : new Blob([data], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
}
