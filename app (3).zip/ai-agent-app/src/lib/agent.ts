import { AgentStep, Msg, Settings, StepType } from '../types';
import { callWithFallback } from './providers';
import { runJs } from './sandbox';
import { ensureSeed, listFiles, readFile, sanitizePath, writeFile, PROJECT_ROOT } from './vfs';

const PROTOCOL = [
  'PROTOCOLO DE RESPOSTA (obrigatorio): responda SOMENTE com um objeto JSON, sem texto fora dele.',
  'Para usar uma ferramenta:',
  '{"observacao":"...","raciocinio":"...","acao":{"tool":"NOME","args":{...}}}',
  'Para encerrar:',
  '{"observacao":"...","raciocinio":"...","final":"resposta final ao usuario"}',
  'Ferramentas:',
  '- list_files: args {} - lista os arquivos com o caminho completo.',
  '- read_file: args {"path":"..."} - le um arquivo.',
  '- write_file: args {"path":"' + PROJECT_ROOT + '/src/index.html","content":"..."} - cria ou sobrescreve.',
  '- append_memory: args {"note":"..."} - acrescenta uma linha em memory.md.',
  '- run_js: args {"code":"..."} - executa JavaScript isolado e devolve o que foi impresso com console.log.',
  'REGRA: todo arquivo de projeto comeca com "' + PROJECT_ROOT + '/".',
  'REGRA: nunca diga que criou um arquivo antes de receber "OK: gravado" da ferramenta.',
  'Use uma ferramenta por resposta.',
].join('\n');

const now = () => new Date().toLocaleTimeString();

const PATH_KEYS = ['path', 'file', 'filename', 'arquivo', 'caminho', 'filepath', 'file_path', 'name', 'nome'];
const CONTENT_KEYS = ['content', 'contents', 'code', 'text', 'conteudo', 'body', 'data', 'source'];

// Aceita o caminho em qualquer nome de campo que o modelo inventar.
function pickArg(args: any, keys: string[]): string {
  if (!args || typeof args !== 'object') return '';
  for (const k of keys) {
    const v = args[k];
    if (typeof v === 'string' && v.trim() !== '') return v.trim();
  }
  return '';
}

function parseJson(text: string): any {
  const a = text.indexOf('{');
  const b = text.lastIndexOf('}');
  if (a < 0 || b <= a) throw new Error('sem JSON');
  return JSON.parse(text.slice(a, b + 1));
}

async function runTool(tool: string, args: any): Promise<string> {
  switch (tool) {
    case 'list_files':
      return listFiles().join('\n');
    case 'read_file': {
      const p = pickArg(args, PATH_KEYS);
      if (!p) throw new Error('Informe o campo "path" com o caminho do arquivo.');
      return readFile(p);
    }
    case 'write_file': {
      const raw = pickArg(args, PATH_KEYS);
      if (!raw) throw new Error('Campo "path" ausente. Use: {"path":"' + PROJECT_ROOT + '/index.html","content":"..."}');
      const content = pickArg(args, CONTENT_KEYS);
      const path = sanitizePath(raw);
      writeFile(path, content);
      return 'OK: gravado ' + path + ' (' + content.length + ' caracteres)';
    }
    case 'append_memory': {
      const cur = readFile('memory.md');
      writeFile('memory.md', cur.trimEnd() + '\n- ' + String(args?.note ?? args?.nota ?? '') + '\n');
      return 'OK: memoria atualizada';
    }
    case 'run_js':
      return runJs(String(args?.code ?? args?.codigo ?? ''));
    default:
      throw new Error('Ferramenta desconhecida: ' + tool);
  }
}

export async function runAgent(p: {
  task: string;
  settings: Settings;
  onStep: (s: AgentStep) => void;
  signal?: AbortSignal;
}): Promise<{ tokens: number; iterations: number; files: string[]; provider?: string }> {
  const push = (type: StepType, content: string) => p.onStep({ type, content, time: now() });
  ensureSeed();
  const system = [readFile('agentes.md'), readFile('memory.md'), readFile('skills.md'), PROTOCOL].join('\n\n---\n\n');
  let msgs: Msg[] = [{ role: 'user', text: 'TAREFA: ' + p.task }];
  const max = p.settings.maxIter || 8;
  let tokens = 0;
  let provider: string | undefined;
  const created: string[] = [];

  for (let i = 1; i <= max; i++) {
    if (p.signal?.aborted) throw new Error('Cancelado');
    const r = await callWithFallback(p.settings, system, msgs, { json: true, signal: p.signal }, (m) => push('INFO', m));
    tokens += r.totalTokens;
    if (i === 1) {
      provider = r.provider + ' (' + r.model + ')';
      push('INFO', 'Provedor: ' + provider);
    }

    let obj: any;
    try {
      obj = parseJson(r.text);
    } catch {
      push('ERRO', 'Resposta fora do formato JSON; pedindo novamente.');
      msgs.push({ role: 'model', text: r.text }, { role: 'user', text: 'Resposta invalida. Responda somente com o JSON do protocolo.' });
      continue;
    }

    if (obj.observacao) push('OBSERVAÇÃO', String(obj.observacao));
    if (obj.raciocinio) push('RACIOCÍNIO', String(obj.raciocinio));

    if (typeof obj.final === 'string') {
      if (created.length) {
        push('FINAL', obj.final + '\n\nArquivos gravados:\n' + created.map((f) => '- ' + f).join('\n'));
      } else {
        push('FINAL', obj.final);
        push('INFO', 'Nenhum arquivo foi gravado nesta tarefa.');
      }
      return { tokens, iterations: i, files: created, provider };
    }

    const tool = obj.acao?.tool;
    if (!tool) {
      msgs.push({ role: 'model', text: r.text }, { role: 'user', text: 'Informe uma acao (tool) ou o campo final.' });
      continue;
    }

    let result: string;
    try {
      result = await runTool(tool, obj.acao.args);
      push('AÇÃO', tool + ' ' + JSON.stringify(obj.acao.args ?? {}).slice(0, 400));
    } catch (e: any) {
      result = 'ERRO: ' + (e?.message ?? String(e));
      push('AÇÃO', tool + ' (falhou)');
    }

    if (result.startsWith('OK: gravado ')) {
      const path = result.slice('OK: gravado '.length).split(' (')[0];
      if (!created.includes(path)) created.push(path);
    }
    push('RESULTADO', result.slice(0, 600));
    msgs.push({ role: 'model', text: r.text }, { role: 'user', text: 'RESULTADO DA FERRAMENTA:\n' + result.slice(0, 6000) });

    if (msgs.length > 17) msgs = [msgs[0], ...msgs.slice(-14)];
  }

  push('ERRO', 'Limite de iteracoes atingido (' + max + ').');
  return { tokens, iterations: max, files: created, provider };
}
