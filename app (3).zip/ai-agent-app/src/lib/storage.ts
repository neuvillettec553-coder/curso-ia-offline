import { Task, Settings } from '../types';

const KEY = 'agent.settings.v2';
const TASKS = 'agent.tasks.v2';

export const DEFAULT_SETTINGS: Settings = {
  keys: { gemini: '', groq: '', openrouter: '' },
  models: {
    gemini: 'gemini-3.5-flash-lite',
    groq: 'openai/gpt-oss-20b',
    openrouter: 'qwen/qwen3.8-27b:free',
  },
  github: { token: '', repo: '', branch: 'main', folder: 'agent-output' },
  maxIter: 8,
  keepTasks: 50,
};

export function loadSettings(): Settings {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return DEFAULT_SETTINGS;
    const s = JSON.parse(raw);
    return {
      keys: { ...DEFAULT_SETTINGS.keys, ...s.keys },
      models: { ...DEFAULT_SETTINGS.models, ...s.models },
      github: { ...DEFAULT_SETTINGS.github, ...s.github },
      maxIter: s.maxIter || DEFAULT_SETTINGS.maxIter,
      keepTasks: s.keepTasks || DEFAULT_SETTINGS.keepTasks,
    };
  } catch {
    return DEFAULT_SETTINGS;
  }
}

export function saveSettings(s: Settings) {
  localStorage.setItem(KEY, JSON.stringify(s));
}

export function loadTasks(): Task[] {
  try {
    const raw = localStorage.getItem(TASKS);
    const list = raw ? JSON.parse(raw) : [];
    return Array.isArray(list) ? list : [];
  } catch {
    return [];
  }
}

export function saveTasks(list: Task[], keep: number) {
  const trimmed = [...list].sort((a, b) => b.startedAt - a.startedAt).slice(0, keep);
  // Tarefas "running" viram "stopped" ao recarregar: o loop nao sobrevive a um fechamento.
  const fixed = trimmed.map((t) => (t.status === 'running' ? { ...t, status: 'stopped' as const, error: 'Interrompida ao fechar o app.' } : t));
  try {
    localStorage.setItem(TASKS, JSON.stringify(fixed));
  } catch {
    // Espaco cheio: mantem apenas as 20 mais recentes.
    localStorage.setItem(TASKS, JSON.stringify(fixed.slice(0, 20)));
  }
}

// Backup completo: chaves, modelos, tarefas e arquivos virtuais.
export function exportBackup(settings: Settings, tasks: Task[]): string {
  const files: Record<string, string> = {};
  for (let i = 0; i < localStorage.length; i++) {
    const k = localStorage.key(i);
    if (k && k.startsWith('vfs:file:')) files[k] = localStorage.getItem(k) ?? '';
  }
  return JSON.stringify({ app: 'ai-agent', version: 2, exportedAt: new Date().toISOString(), settings, tasks, files }, null, 2);
}

export function importBackup(json: string): { tasks: number; files: number } {
  const data = JSON.parse(json);
  if (data.files) for (const [k, v] of Object.entries(data.files as Record<string, string>)) localStorage.setItem(k, v);
  if (data.tasks) localStorage.setItem(TASKS, JSON.stringify(data.tasks));
  if (data.settings) localStorage.setItem(KEY, JSON.stringify(data.settings));
  const idx = Object.keys(data.files ?? {}).map((k) => k.replace('vfs:file:', ''));
  localStorage.setItem('vfs:index', JSON.stringify(idx));
  return { tasks: (data.tasks ?? []).length, files: idx.length };
}
