import { Settings } from '../types';

function toBase64(s: string): string {
  const bytes = new TextEncoder().encode(s);
  let bin = '';
  for (let i = 0; i < bytes.length; i += 0x8000) {
    bin += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
  }
  return btoa(bin);
}

async function gh(url: string, token: string, init: RequestInit = {}) {
  return fetch('https://api.github.com' + url, {
    ...init,
    headers: {
      Accept: 'application/vnd.github+json',
      Authorization: 'Bearer ' + token,
      'Content-Type': 'application/json',
    },
  });
}

export async function pushFiles(
  s: Settings,
  files: Record<string, string>,
  onProgress: (msg: string) => void
): Promise<void> {
  const { token, repo, branch, folder } = s.github;
  if (!token.trim() || !repo.trim()) throw new Error('Preencha token e repositorio (usuario/repo) na aba Config.');
  const b = branch.trim() || 'main';
  for (const [name, content] of Object.entries(files)) {
    const path = (folder.trim() ? folder.trim().replace(/\/+$/, '') + '/' : '') + name;
    const api = '/repos/' + repo.trim() + '/contents/' + path.split('/').map(encodeURIComponent).join('/');
    onProgress('Enviando ' + path + '...');
    let sha: string | undefined;
    const cur = await gh(api + '?ref=' + encodeURIComponent(b), token.trim());
    if (cur.ok) sha = (await cur.json()).sha;
    else if (cur.status !== 404) throw new Error('GitHub ' + cur.status + ' ao consultar ' + path);
    const res = await gh(api, token.trim(), {
      method: 'PUT',
      body: JSON.stringify({ message: 'Agente: atualiza ' + path, content: toBase64(content), branch: b, sha }),
    });
    if (!res.ok) throw new Error('GitHub ' + res.status + ': ' + (await res.text()).slice(0, 160));
  }
  onProgress('Concluido: ' + Object.keys(files).length + ' arquivo(s) enviados.');
}
