// Executa JavaScript num Web Worker isolado, com tempo limite. Nao acessa o DOM nem as chaves.
function workerMain() {
  const out: string[] = [];
  const fmt = (a: any[]) => a.map((x) => (typeof x === 'string' ? x : JSON.stringify(x))).join(' ');
  const log = (...a: any[]) => { out.push(fmt(a)); };
  (self as any).console = { log, error: log, warn: log, info: log };
  self.onmessage = async (e: MessageEvent) => {
    try {
      const AF = Object.getPrototypeOf(async function () {}).constructor;
      const r = await new AF(e.data)();
      if (r !== undefined) out.push('retorno: ' + JSON.stringify(r));
      (self as any).postMessage({ ok: true, out: out.join('\n') });
    } catch (err: any) {
      (self as any).postMessage({ ok: false, out: out.join('\n') + '\nERRO: ' + (err?.message ?? err) });
    }
  };
}

export function runJs(code: string, timeoutMs = 5000): Promise<string> {
  return new Promise((resolve) => {
    const url = URL.createObjectURL(
      new Blob(['(' + workerMain.toString() + ')()'], { type: 'text/javascript' })
    );
    const w = new Worker(url);
    const done = (text: string) => {
      clearTimeout(timer);
      w.terminate();
      URL.revokeObjectURL(url);
      resolve(text.trim() || '(sem saida)');
    };
    const timer = setTimeout(() => done('ERRO: tempo limite de ' + timeoutMs / 1000 + 's excedido'), timeoutMs);
    w.onmessage = (e) => done(e.data.out);
    w.onerror = (e) => done('ERRO: ' + e.message);
    w.postMessage(code);
  });
}
