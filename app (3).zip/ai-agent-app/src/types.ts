export type ProviderId = 'gemini' | 'groq' | 'openrouter';
export type StepType = 'OBSERVAÇÃO' | 'RACIOCÍNIO' | 'AÇÃO' | 'RESULTADO' | 'FINAL' | 'ERRO' | 'INFO';
export type TaskStatus = 'running' | 'done' | 'error' | 'stopped';

export interface AgentStep {
  type: StepType;
  content: string;
  time: string;
}

export interface Msg {
  role: 'user' | 'model';
  text: string;
}

export interface LLMResult {
  text: string;
  latencyMs: number;
  promptTokens: number;
  outputTokens: number;
  totalTokens: number;
  provider: ProviderId;
  model: string;
}

export interface Task {
  id: string;
  title: string;
  prompt: string;
  status: TaskStatus;
  startedAt: number;
  endedAt?: number;
  steps: AgentStep[];
  files: string[];
  tokens: number;
  iterations: number;
  provider?: string;
  error?: string;
}

export interface Settings {
  keys: Record<ProviderId, string>;
  models: Record<ProviderId, string>;
  github: { token: string; repo: string; branch: string; folder: string };
  maxIter: number;
  keepTasks: number;
}
