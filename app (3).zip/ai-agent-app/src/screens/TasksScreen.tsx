import React, { useState } from 'react';
import { Task } from '../types';

const STATUS: Record<Task['status'], { label: string; cls: string }> = {
  running: { label: 'EM EXECUCAO', cls: 'run' },
  done: { label: 'CONCLUIDA', cls: 'done' },
  error: { label: 'ERRO', cls: 'error' },
  stopped: { label: 'INTERROMPIDA', cls: 'stop' },
};

function when(ts: number): string {
  const d = new Date(ts);
  return d.toLocaleDateString() + ' ' + d.toLocaleTimeString().slice(0, 5);
}

function dur(t: Task): string {
  if (!t.endedAt) return '-';
  const s = (t.endedAt - t.startedAt) / 1000;
  return s < 60 ? s.toFixed(1) + ' s' : Math.round(s / 60) + ' min';
}

export function TasksScreen(p: { tasks: Task[]; onOpen: (id: string) => void; onDelete: (id: string) => void; onClear: () => void }) {
  const [q, setQ] = useState('');
  const [filter, setFilter] = useState<'all' | Task['status']>('all');

  const list = p.tasks
    .filter((t) => (filter === 'all' ? true : t.status === filter))
    .filter((t) => (q.trim() ? (t.title + t.prompt).toLowerCase().includes(q.toLowerCase()) : true))
    .sort((a, b) => b.startedAt - a.startedAt);

  const counts = {
    all: p.tasks.length,
    running: p.tasks.filter((t) => t.status === 'running').length,
    done: p.tasks.filter((t) => t.status === 'done').length,
    error: p.tasks.filter((t) => t.status === 'error').length,
    stopped: p.tasks.filter((t) => t.status === 'stopped').length,
  };

  return (
    <>
      <div className="searchbar">
        <input placeholder="Buscar nas tarefas" value={q} onChange={(e) => setQ(e.target.value)} />
      </div>
      <div className="chips">
        {([['all', 'Todas'], ['running', 'Em execucao'], ['done', 'Concluidas'], ['error', 'Erros'], ['stopped', 'Interrompidas']] as const).map(([k, label]) => (
          <button key={k} className={'chip' + (filter === k ? ' on' : '')} onClick={() => setFilter(k as any)}>
            {label} <span className="chip-n">{(counts as any)[k]}</span>
          </button>
        ))}
      </div>

      <div className="scroll">
        {list.length === 0 && (
          <div className="empty">
            <div className="empty-ring" />
            <p>Nenhuma tarefa aqui ainda.</p>
            <p className="muted">Toque em + para descrever o que voce quer programar. Cada execucao fica salva com o log completo.</p>
          </div>
        )}
        {list.map((t) => (
          <div key={t.id} className={'task ' + STATUS[t.status].cls} onClick={() => p.onOpen(t.id)}>
            <div className="task-head">
              <span className={'pill ' + STATUS[t.status].cls}>{STATUS[t.status].label}</span>
              <span className="muted">{when(t.startedAt)}</span>
            </div>
            <div className="task-title">{t.title}</div>
            <div className="task-meta">
              <span>{t.steps.length} passo(s)</span>
              <span>{dur(t)}</span>
              <span>{t.tokens} tokens</span>
              {t.files.length > 0 && <span className="files">{t.files.length} arquivo(s)</span>}
            </div>
            <button
              className="icon-btn"
              onClick={(e) => { e.stopPropagation(); if (window.confirm('Apagar esta tarefa?')) p.onDelete(t.id); }}
              aria-label="Apagar"
            >
              ×
            </button>
          </div>
        ))}
      </div>

      <div className="dock">
        <button className="btn big" onClick={() => p.onOpen('')}>+ Nova tarefa</button>
      </div>
    </>
  );
}
