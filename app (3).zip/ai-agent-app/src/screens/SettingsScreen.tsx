import React, { useRef, useState } from 'react';
import { LABEL, ORDER } from '../lib/providers';
import { DEFAULT_SETTINGS, exportBackup, importBackup } from '../lib/storage';
import { buildZip, allFiles, downloadBlob, listFiles } from '../lib/vfs';
import { ProviderId, Settings, Task } from '../types';

const GUIDE: Record<ProviderId, { url: string; steps: string }> = {
  gemini: {
    url: 'https://aistudio.google.com/apikey',
    steps: 'Entre com sua conta Google, toque em "Create API key", copie a chave (comeca com AIza).',
  },
  groq: {
    url: 'https://console.groq.com/keys',
    steps: 'Crie uma conta, toque em "Create API Key", copie a chave (comeca com gsk_).',
  },
  openrouter: {
    url: 'https://openrouter.ai/keys',
    steps: 'Crie uma conta, toque em "Create Key", copie a chave (comeca com sk-or-). Use modelos com sufixo :free.',
  },
};

export function SettingsScreen(p: { settings: Settings; onChange: (s: Settings) => void; tasks: Task[]; onRestoreTasks: (t: Task[]) => void }) {
  const [show, setShow] = useState(false);
  const [msg, setMsg] = useState('');
  const fileRef = useRef<HTMLInputElement>(null);
  const s = p.settings;

  const setKey = (id: ProviderId, v: string) => p.onChange({ ...s, keys: { ...s.keys, [id]: v } });
  const setModel = (id: ProviderId, v: string) => p.onChange({ ...s, models: { ...s.models, [id]: v } });
  const setGh = (k: keyof Settings['github'], v: string) => p.onChange({ ...s, github: { ...s.github, [k]: v } });

  const backup = () => {
    downloadBlob(exportBackup(s, p.tasks), 'agente-backup.json', 'application/json');
    setMsg('Backup gerado: agente-backup.json');
  };

  const restore = async (f: File) => {
    try {
      const r = importBackup(await f.text());
      setMsg('Backup restaurado: ' + r.tasks + ' tarefa(s), ' + r.files + ' arquivo(s). Recarregue o app.');
    } catch (e: any) {
      setMsg('Falha ao restaurar: ' + e.message);
    }
  };

  return (
    <div className="scroll">
      <p className="muted">Tudo fica salvo apenas neste aparelho. Uma chave basta; com mais de uma, o app troca sozinho se uma atingir o limite (ordem: Gemini, Groq, OpenRouter).</p>
      <label className="row"><input type="checkbox" checked={show} onChange={(e) => setShow(e.target.checked)} /> Mostrar chaves</label>

      {ORDER.map((id) => (
        <div key={id} className="card">
          <h3>{LABEL[id]}</h3>
          <p className="muted">
            <a href={GUIDE[id].url} target="_blank" rel="noreferrer">{GUIDE[id].url}</a><br />
            {GUIDE[id].steps}
          </p>
          <input type={show ? 'text' : 'password'} placeholder="Cole a chave aqui" value={s.keys[id]} autoCapitalize="none" onChange={(e) => setKey(id, e.target.value)} />
          <input value={s.models[id]} autoCapitalize="none" onChange={(e) => setModel(id, e.target.value)} />
          <span className="muted">Modelo (troque se o provedor renomear ou descontinuar)</span>
        </div>
      ))}

      <div className="card">
        <h3>GitHub (opcional)</h3>
        <p className="muted">Para enviar os arquivos do agente ao seu repositorio. Crie um token em github.com/settings/tokens (fine-grained, permissao Contents: Read and write).</p>
        <input type={show ? 'text' : 'password'} placeholder="Token (github_pat_...)" value={s.github.token} autoCapitalize="none" onChange={(e) => setGh('token', e.target.value)} />
        <input placeholder="usuario/repositorio" value={s.github.repo} autoCapitalize="none" onChange={(e) => setGh('repo', e.target.value)} />
        <input placeholder="branch (main)" value={s.github.branch} autoCapitalize="none" onChange={(e) => setGh('branch', e.target.value)} />
        <input placeholder="pasta de destino (agent-output)" value={s.github.folder} autoCapitalize="none" onChange={(e) => setGh('folder', e.target.value)} />
      </div>

      <div className="card">
        <h3>Agente</h3>
        <label>Maximo de passos por tarefa: {s.maxIter}</label>
        <input type="range" min={2} max={20} value={s.maxIter} onChange={(e) => p.onChange({ ...s, maxIter: Number(e.target.value) })} />
        <label>Tarefas mantidas no historico: {s.keepTasks}</label>
        <input type="range" min={10} max={200} step={10} value={s.keepTasks} onChange={(e) => p.onChange({ ...s, keepTasks: Number(e.target.value) })} />
      </div>

      <div className="card">
        <h3>Backup e manutencao</h3>
        <p className="muted">O backup guarda suas chaves, modelos, tarefas e todos os arquivos, num unico JSON. Use antes de trocar de celular ou limpar o navegador.</p>
        <button className="btn" onClick={backup}>Baixar backup (.json)</button>
        <button className="btn dark" onClick={() => fileRef.current?.click()}>Restaurar backup</button>
        <input ref={fileRef} type="file" accept=".json,application/json" style={{ display: 'none' }} onChange={(e) => e.target.files?.[0] && restore(e.target.files[0])} />
        <button className="btn dark" onClick={() => downloadBlob(buildZip(), 'agente-arquivos.zip', 'application/zip')}>Baixar arquivos (.zip)</button>
        <span className="muted">{p.tasks.length} tarefa(s) · {listFiles().length} arquivo(s) · {Object.keys(allFiles()).length} no ZIP</span>
      </div>

      <div className="card">
        <h3>Padroes</h3>
        <button className="btn amber" onClick={() => p.onChange({ ...DEFAULT_SETTINGS, keys: s.keys, github: s.github })}>Restaurar modelos e limites</button>
        <span className="muted">Mantem suas chaves e a configuracao do GitHub.</span>
        <button className="btn red" onClick={() => { if (window.confirm('Apagar todas as tarefas do historico?')) p.onRestoreTasks([]); }}>Apagar historico de tarefas</button>
      </div>

      {msg && <p className="muted">{msg}</p>}
    </div>
  );
}
