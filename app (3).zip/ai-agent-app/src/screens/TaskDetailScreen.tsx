import React, { useEffect, useRef, useState } from 'react';
import { StepType, Task } from '../types';

const CLS: Record<StepType, string> = {
  'OBSERVAÇÃO': 'obs',
  'RACIOCÍNIO': 'rac',
  'AÇÃO': 'acao',
  RESULTADO: 'res',
  FINAL: 'final',
  ERRO: 'err',
  INFO: 'info',
};

const LABELS: Record<StepType, string> = {
  'OBSERVAÇÃO': 'Observar',
  'RACIOCÍNIO': 'Raciocinar',
  'AÇÃO': 'Agir',
  RESULTADO: 'Resultado',
  FINAL: 'Conclusao',
  ERRO: 'Erro',
  INFO: 'Info',
};

export function TaskDetailScreen(p: {
  task: Task;
  busy: boolean;
  onRun: (prompt: string) => void;
  onBack: () => void;
  onDelete: () => void;
  onOpenFile: () => void;
}) {
  const [prompt, setPrompt] = useState('');
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [p.task.steps.length]);

  const isNew = p.task.id === '';
  const t = p.task;

  const submit = () => {
    const value = prompt.trim() || (isNew ? '' : t.prompt);
    if (!value || p.busy) return;
    setPrompt('');
    p.onRun(value);
  };

  const copyLog = () => {
    const text = t.steps.map((s) => '[' + s.type + '] ' + s.time + '\n' + s.content).join('\n\n');
    navigator.clipboard?.writeText(text);
  };

  return (
    <>
      <div className="detail-bar">
        <button className="ghost" onClick={p.onBack}>← Voltar</button>
        <div className="detail-title">{isNew ? 'Nova tarefa' : t.title}</div>
        <button className="ghost" onClick={copyLog}>Copiar log</button>
      </div>

      {!isNew && (
        <div className="stat-row">
          <div className="stat"><span className="stat-k">Status</span><span className="stat-v">{t.status}</span></div>
          <div className="stat"><span className="stat-k">Passos</span><span className="stat-v">{t.steps.length}</span></div>
          <div className="stat"><span className="stat-k">Tokens</span><span className="stat-v">{t.tokens}</span></div>
          <div className="stat"><span className="stat-k">Provedor</span><span className="stat-v small">{t.provider ?? '-'}</span></div>
        </div>
      )}

      {t.files.length > 0 && (
        <div className="card files-card">
          <b>Arquivos gravados</b>
          {t.files.map((f) => (
            <button key={f} className="link" onClick={p.onOpenFile}>{f}</button>
          ))}
        </div>
      )}
      {t.error && <div className="card errc">{t.error}</div>}

      <div className="scroll">
        {isNew && (
          <div className="empty">
            <div className="empty-ring" />
            <p>Descreva a tarefa abaixo.</p>
            <p className="muted">O agente observa, raciocina e age com ferramentas. Os arquivos criados ficam em agent-output/.</p>
          </div>
        )}
        {t.steps.map((s, i) => (
          <div key={i} className={'step ' + CLS[s.type]}>
            <div className="tag">
              <span className="tag-name">{LABELS[s.type]}</span>
              <span className="tag-type">[{s.type}]</span>
              <span className="tag-time">{s.time}</span>
            </div>
            <div className="body">{s.content}</div>
          </div>
        ))}
        {t.status === 'running' && <p className="muted pulse">Executando...</p>}
        <div ref={endRef} />
      </div>

      <div className="dock composer">
        <textarea
          rows={isNew ? 4 : 2}
          placeholder={isNew ? 'Descreva a tarefa...' : 'Nova tarefa (o contexto atual sera usado)'}
          value={prompt}
          onChange={(e) => setPrompt(e.target.value)}
        />
        <button className="btn big" onClick={submit} disabled={p.busy}>
          {p.busy ? 'Aguarde' : 'Executar'}
        </button>
      </div>
    </>
  );
}
