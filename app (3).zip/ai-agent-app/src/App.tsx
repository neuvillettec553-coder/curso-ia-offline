import React, { useEffect, useState } from 'react';
import { TasksScreen } from './screens/TasksScreen';
import { TaskDetailScreen } from './screens/TaskDetailScreen';
import { ContextScreen } from './screens/ContextScreen';
import { PlaygroundScreen } from './screens/PlaygroundScreen';
import { SettingsScreen } from './screens/SettingsScreen';
import { loadSettings, loadTasks, saveSettings, saveTasks } from './lib/storage';
import { ensureSeed } from './lib/vfs';
import { runAgent } from './lib/agent';
import { AgentStep, Settings, Task } from './types';

type Tab = 'tasks' | 'context' | 'play' | 'config';

const TABS: { key: Tab; label: string; icon: string }[] = [
  { key: 'tasks', label: 'Tarefas', icon: '▤' },
  { key: 'context', label: 'Contexto', icon: '◍' },
  { key: 'play', label: 'Play', icon: '⌁' },
  { key: 'config', label: 'Config', icon: '⚙' },
];

const TITLES: Record<Tab, string> = {
  tasks: 'Centro de Tarefas',
  context: 'Gerenciador de Contexto',
  play: 'Playground',
  config: 'Configuracoes',
};

export function App() {
  const [tab, setTab] = useState<Tab>('tasks');
  const [settings, setSettings] = useState<Settings>(loadSettings);
  const [tasks, setTasks] = useState<Task[]>(loadTasks);
  const [openId, setOpenId] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [, force] = useState(0);

  useEffect(() => {
    ensureSeed();
    setTasks(loadTasks());
  }, []);

  const persist = (list: Task[]) => {
    setTasks(list);
    saveTasks(list, settings.keepTasks);
  };

  const update = (s: Settings) => {
    setSettings(s);
    saveSettings(s);
  };

  const closeTask = () => {
    setOpenId(null);
    setTasks(loadTasks());
  };

  // Executa uma tarefa: cria o registro, roda o loop e grava os passos a cada atualizacao.
  const startTask = async (prompt: string) => {
    if (busy) return;
    setBusy(true);
    const id = 't' + Date.now();
    const task: Task = {
      id,
      title: prompt.length > 60 ? prompt.slice(0, 60) + '...' : prompt,
      prompt,
      status: 'running',
      startedAt: Date.now(),
      steps: [],
      files: [],
      tokens: 0,
      iterations: 0,
    };
    let list = [task, ...loadTasks()];
    persist(list);
    setOpenId(id);

    const patch = (fn: (t: Task) => Task) => {
      list = list.map((t) => (t.id === id ? fn(t) : t));
      persist(list);
      force((n) => n + 1);
    };

    try {
      const r = await runAgent({
        task: prompt,
        settings,
        onStep: (s: AgentStep) => patch((t) => ({ ...t, steps: [...t.steps, s] })),
      });
      patch((t) => ({
        ...t,
        status: 'done',
        endedAt: Date.now(),
        tokens: r.tokens,
        iterations: r.iterations,
        files: r.files,
        provider: r.provider,
      }));
    } catch (e: any) {
      patch((t) => ({
        ...t,
        status: e?.message === 'Cancelado' ? 'stopped' : 'error',
        endedAt: Date.now(),
        error: e?.message ?? String(e),
      }));
    } finally {
      setBusy(false);
    }
  };

  const open = tasks.find((t) => t.id === openId) ?? null;
  const inDetail = tab === 'tasks' && open;

  return (
    <div className="app">
      <header className="topbar">
        <div className="brand">
          <span className="brand-dot" />
          <span className="brand-name">AGENTE<span className="brand-accent">.IA</span></span>
        </div>
        <div className="topbar-title">{inDetail ? 'Detalhe da Tarefa' : TITLES[tab]}</div>
        <div className="topbar-chip">{taskViews(tasks)}</div>
      </header>

      <main>
        <section className="pane" style={{ display: tab === 'tasks' && !open ? 'flex' : 'none' }}>
          <TasksScreen tasks={tasks} onOpen={setOpenId} onDelete={(id) => persist(tasks.filter((t) => t.id !== id))} onClear={() => persist([])} />
        </section>
        <section className="pane" style={{ display: tab === 'tasks' && open ? 'flex' : 'none' }}>
          {open && (
            <TaskDetailScreen
              task={open}
              busy={busy}
              onRun={startTask}
              onBack={closeTask}
              onDelete={() => { persist(tasks.filter((t) => t.id !== open.id)); closeTask(); }}
              onOpenFile={() => { setTab('context'); }}
            />
          )}
        </section>
        <section className="pane" style={{ display: tab === 'context' ? 'flex' : 'none' }}>
          <ContextScreen settings={settings} />
        </section>
        <section className="pane" style={{ display: tab === 'play' ? 'flex' : 'none' }}>
          <PlaygroundScreen settings={settings} />
        </section>
        <section className="pane" style={{ display: tab === 'config' ? 'flex' : 'none' }}>
          <SettingsScreen settings={settings} onChange={update} tasks={tasks} onRestoreTasks={(list) => persist(list)} />
        </section>
      </main>

      {!inDetail && (
        <nav>
          {TABS.map((t) => (
            <button key={t.key} className={tab === t.key ? 'on' : ''} onClick={() => { setTab(t.key); if (t.key !== 'tasks') setOpenId(null); }}>
              <span className="nav-icon">{t.icon}</span>
              <span>{t.label}</span>
            </button>
          ))}
        </nav>
      )}
    </div>
  );
}

function taskViews(list: Task[]): string {
  const run = list.filter((t) => t.status === 'running').length;
  return run ? run + ' em execucao' : list.length + ' tarefa(s)';
}
