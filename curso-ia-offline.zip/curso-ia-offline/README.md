# Curso IA Offline

Aplicativo (Progressive Web App) completo do curso de Agentes de Inteligência Artificial para iniciantes absolutos.

Funciona 100% offline depois de instalado no celular.

## Como usar no GitHub (passo a passo bem detalhado)

### 1. Criar o repositório no GitHub

1. Abra o navegador e entre em: https://github.com
2. Faça login na sua conta
3. No canto superior direito, clique no botão **+** e depois em **New repository**
4. Em **Repository name** escreva: `curso-ia-offline`
5. Deixe marcado como **Public**
6. **NÃO** marque a opção "Add a README file"
7. Clique no botão verde **Create repository**

### 2. Fazer o upload dos arquivos

1. Na página do repositório que acabou de criar, clique em **uploading an existing file**
2. Arraste **todos** os arquivos e pastas que estão dentro deste zip (index.html, css, js, icons, manifest.json, sw.js, README.md)
3. Ou clique em "choose your files" e selecione tudo
4. Role a página para baixo
5. No campo **Commit changes** escreva: `Primeira versão do curso`
6. Clique no botão verde **Commit changes**

### 3. Ativar o GitHub Pages (para o app funcionar online e poder instalar)

1. No repositório, clique na aba **Settings** (Configurações)
2. No menu da esquerda, role até encontrar **Pages**
3. Em **Source**, escolha **Deploy from a branch**
4. Em Branch, selecione **main** (ou master) e a pasta **/ (root)**
5. Clique em **Save**
6. Espere 1 ou 2 minutos
7. A página vai mostrar um link parecido com:  
   `https://seu-usuario.github.io/curso-ia-offline/`

### 4. Abrir e instalar no celular

1. No seu Realme C85, abra o Chrome
2. Digite o link que o GitHub Pages gerou
3. Espere a página carregar
4. No Chrome, toque nos **três pontinhos** (menu)
5. Toque em **Adicionar à tela inicial** ou **Instalar aplicativo**
6. Confirme

Pronto! Agora o curso aparece como um ícone de aplicativo no seu celular e funciona offline.

## Estrutura dos arquivos

- `index.html` → página principal
- `css/style.css` → visual do aplicativo
- `js/app.js` → lógica (navegação, progresso, etc.)
- `js/content.js` → todo o conteúdo das aulas
- `manifest.json` → configurações para instalar como app
- `sw.js` → service worker (faz funcionar offline)
- `icons/` → ícones do aplicativo

## Atualizações futuras

Quando eu adicionar mais módulos, você só precisa substituir os arquivos no GitHub (mesmo processo de upload).
