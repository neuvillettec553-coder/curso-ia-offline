/* Lógica principal do aplicativo */

let paginaAtual = 'home';
const AULAS = ['aula-1-1', 'aula-1-2', 'aula-1-3', 'aula-1-4'];

// Inicialização
document.addEventListener('DOMContentLoaded', () => {
  // Esconde loading depois de um tempo curto
  setTimeout(() => {
    document.getElementById('loading-screen').classList.add('hidden');
    document.getElementById('app').classList.remove('hidden');
    navegar('home');
    atualizarProgresso();
    carregarPromptsSalvos();
  }, 600);

  // Menu
  document.getElementById('btn-menu').addEventListener('click', abrirMenu);
  document.getElementById('btn-close-menu').addEventListener('click', fecharMenu);
  document.getElementById('overlay').addEventListener('click', fecharMenu);

  // Links do menu lateral
  document.querySelectorAll('.menu-list a').forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      const page = link.getAttribute('data-page');
      navegar(page);
      fecharMenu();
    });
  });

  // Bottom nav
  document.querySelectorAll('.bottom-nav .nav-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const page = btn.getAttribute('data-page');
      navegar(page);
    });
  });

  // Botão de progresso no header
  document.getElementById('btn-progress').addEventListener('click', () => {
    navegar('home');
  });
});

function abrirMenu() {
  document.getElementById('sidebar').classList.add('open');
  document.getElementById('overlay').classList.remove('hidden');
}

function fecharMenu() {
  document.getElementById('sidebar').classList.remove('open');
  document.getElementById('overlay').classList.add('hidden');
}

function navegar(pagina) {
  paginaAtual = pagina;
  const content = document.getElementById('content');
  const dados = CONTEUDO[pagina];

  if (!dados) {
    content.innerHTML = `<div class="card"><h2>Página não encontrada</h2></div>`;
    return;
  }

  document.getElementById('header-title').textContent = dados.title;
  content.innerHTML = dados.html;

  // Atualiza status das aulas se estiver no módulo 1
  if (pagina === 'modulo1') {
    AULAS.forEach(aula => {
      const el = document.getElementById('status-' + aula);
      if (el) {
        el.textContent = estaConcluida(aula) ? '✅ Concluída' : 'Não iniciada';
      }
    });
  }

  // Atualiza bottom nav
  document.querySelectorAll('.bottom-nav .nav-btn').forEach(btn => {
    btn.classList.toggle('active', btn.getAttribute('data-page') === pagina || 
      (pagina.startsWith('aula-') && btn.getAttribute('data-page') === 'modulo1') ||
      (pagina.startsWith('modulo') && btn.getAttribute('data-page') === 'modulo1' && pagina !== 'home'));
  });

  // Se for playground, recarrega a lista
  if (pagina === 'playground') {
    carregarPromptsSalvos();
  }

  // Scroll para o topo
  window.scrollTo(0, 0);
}

function marcarConcluida(aulaId) {
  let concluidas = JSON.parse(localStorage.getItem('aulasConcluidas') || '[]');
  if (!concluidas.includes(aulaId)) {
    concluidas.push(aulaId);
    localStorage.setItem('aulasConcluidas', JSON.stringify(concluidas));
  }
  atualizarProgresso();
}

function estaConcluida(aulaId) {
  const concluidas = JSON.parse(localStorage.getItem('aulasConcluidas') || '[]');
  return concluidas.includes(aulaId);
}

function atualizarProgresso() {
  const concluidas = JSON.parse(localStorage.getItem('aulasConcluidas') || '[]');
  const total = AULAS.length;
  const percentual = Math.round((concluidas.length / total) * 100);

  const barra = document.getElementById('progress-geral');
  const texto = document.getElementById('progress-texto');

  if (barra) barra.style.width = percentual + '%';
  if (texto) texto.textContent = percentual + '% concluído (' + concluidas.length + ' de ' + total + ' aulas do Módulo 1)';
}

/* Playground de prompts */
function salvarPrompt() {
  const texto = document.getElementById('prompt-input').value.trim();
  if (!texto) {
    alert('Escreva algum prompt antes de salvar.');
    return;
  }

  let prompts = JSON.parse(localStorage.getItem('meusPrompts') || '[]');
  prompts.unshift({
    id: Date.now(),
    texto: texto,
    data: new Date().toLocaleDateString('pt-BR')
  });
  localStorage.setItem('meusPrompts', JSON.stringify(prompts));
  document.getElementById('prompt-input').value = '';
  carregarPromptsSalvos();
  alert('Prompt salvo com sucesso!');
}

function limparPrompt() {
  document.getElementById('prompt-input').value = '';
}

function carregarPromptsSalvos() {
  const container = document.getElementById('lista-prompts');
  if (!container) return;

  const prompts = JSON.parse(localStorage.getItem('meusPrompts') || '[]');

  if (prompts.length === 0) {
    container.innerHTML = '<p style="color:var(--text-muted)">Nenhum prompt salvo ainda.</p>';
    return;
  }

  container.innerHTML = prompts.map(p => `
    <div class="card" style="margin-bottom:12px">
      <p style="font-size:0.8rem;color:var(--text-muted)">${p.data}</p>
      <div class="code-block" style="margin:8px 0">${escapeHtml(p.texto)}</div>
      <button class="btn btn-secondary" style="font-size:0.85rem;padding:8px 12px" onclick="copiarTexto(\`${escapeHtml(p.texto).replace(/`/g, '\\`')}\`)">Copiar</button>
      <button class="btn btn-secondary" style="font-size:0.85rem;padding:8px 12px" onclick="apagarPrompt(${p.id})">Apagar</button>
    </div>
  `).join('');
}

function apagarPrompt(id) {
  let prompts = JSON.parse(localStorage.getItem('meusPrompts') || '[]');
  prompts = prompts.filter(p => p.id !== id);
  localStorage.setItem('meusPrompts', JSON.stringify(prompts));
  carregarPromptsSalvos();
}

function copiarTexto(texto) {
  navigator.clipboard.writeText(texto).then(() => {
    alert('Copiado! Agora é só colar no PocketPal.');
  }).catch(() => {
    alert('Não foi possível copiar automaticamente. Selecione o texto e copie manualmente.');
  });
}

function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

/* Service Worker para funcionamento offline */
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('./sw.js').catch(err => {
      console.log('Service Worker não registrado:', err);
    });
  });
}
