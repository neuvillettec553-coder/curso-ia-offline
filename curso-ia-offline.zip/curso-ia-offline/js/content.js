/* 
  CONTEÚDO DO CURSO
  Escrito de forma extremamente simples, como se a pessoa nunca tivesse visto nada de tecnologia.
*/

const CONTEUDO = {
  home: {
    title: "Início",
    html: `
      <div class="card">
        <h2>Olá! Seja muito bem-vindo(a)</h2>
        <p>Este é o seu curso de <strong>Agentes de Inteligência Artificial</strong> feito especialmente para rodar no celular, offline.</p>
        <p>Eu preparei tudo pensando que você <strong>não sabe absolutamente nada</strong> sobre o assunto. Vamos do zero absoluto.</p>
        
        <div class="destaque">
          <strong>O que é um Agente de IA?</strong><br>
          Imagine que você tem um funcionário virtual muito inteligente. Você dá uma tarefa para ele (por exemplo: “pesquise sobre Python e me faça um resumo”). Ele pensa, busca informações, organiza e te entrega o resultado. Isso é um agente.
        </div>

        <p>Neste curso você vai aprender a criar esses “funcionários virtuais” que funcionam mesmo sem internet.</p>
      </div>

      <div class="card">
        <h2>Seu progresso</h2>
        <div class="progress-bar">
          <div class="progress-fill" id="progress-geral"></div>
        </div>
        <p id="progress-texto">0% concluído</p>
      </div>

      <div class="card">
        <h2>Por onde começar?</h2>
        <p>Clique no botão abaixo. Ele vai te levar para a primeira aula. Não pule etapas.</p>
        <button class="btn btn-block" onclick="navegar('aula-1-1')">Começar a primeira aula agora →</button>
      </div>

      <div class="card">
        <h2>Mapa completo do curso</h2>
        <a href="#" class="modulo-card" onclick="navegar('modulo1'); return false;">
          <h3>Módulo 1 – Fundamentos Visuais e Offline</h3>
          <p>Entender como a IA pensa + rodar modelos no celular</p>
        </a>
        <a href="#" class="modulo-card" onclick="navegar('modulo2'); return false;">
          <h3>Módulo 2 – Python Essencial para IA</h3>
          <p>Aprender a programar do zero (só o necessário)</p>
        </a>
        <a href="#" class="modulo-card" onclick="navegar('modulo3'); return false;">
          <h3>Módulo 3 – Sistemas Multiagentes (CrewAI)</h3>
          <p>Criar vários agentes que trabalham juntos</p>
        </a>
        <a href="#" class="modulo-card" onclick="navegar('modulo4'); return false;">
          <h3>Módulo 4 – Arquiteturas Avançadas (LangGraph)</h3>
          <p>Criar fluxos inteligentes com correção automática</p>
        </a>
      </div>
    `
  },

  modulo1: {
    title: "Módulo 1",
    html: `
      <div class="card">
        <h2>Módulo 1 – Fundamentos Visuais e Offline</h2>
        <p>Neste módulo você vai aprender o básico de como conversar com a IA e como rodar uma IA no seu próprio celular, sem precisar de internet.</p>
        
        <div class="destaque">
          <strong>Por que começar por aqui?</strong><br>
          Porque se você tentar programar sem entender como a IA pensa, você vai se frustrar. Aqui a gente constrói a base sólida.
        </div>
      </div>

      <a href="#" class="modulo-card" onclick="navegar('aula-1-1'); return false;">
        <h3>Aula 1.1 – O que é Engenharia de Prompt</h3>
        <p>Aprenda a falar com a IA de forma clara</p>
        <div class="status" id="status-aula-1-1">Não iniciada</div>
      </a>

      <a href="#" class="modulo-card" onclick="navegar('aula-1-2'); return false;">
        <h3>Aula 1.2 – Instalando a IA no celular (PocketPal)</h3>
        <p>Passo a passo para rodar modelos offline</p>
        <div class="status" id="status-aula-1-2">Não iniciada</div>
      </a>

      <a href="#" class="modulo-card" onclick="navegar('aula-1-3'); return false;">
        <h3>Aula 1.3 – Praticando prompts de verdade</h3>
        <p>Exercícios práticos com o modelo no celular</p>
        <div class="status" id="status-aula-1-3">Não iniciada</div>
      </a>

      <a href="#" class="modulo-card" onclick="navegar('aula-1-4'); return false;">
        <h3>Aula 1.4 – Criando seu primeiro “mini-agente”</h3>
        <p>Transformando prompt em agente simples</p>
        <div class="status" id="status-aula-1-4">Não iniciada</div>
      </a>
    `
  },

  "aula-1-1": {
    title: "Aula 1.1",
    html: `
      <div class="aula-header">
        <div class="passo">Módulo 1 · Aula 1.1</div>
        <h2>O que é Engenharia de Prompt?</h2>
      </div>

      <div class="card">
        <h3>O que é isso?</h3>
        <p>Imagine que a Inteligência Artificial é uma pessoa muito inteligente, mas que só entende exatamente o que você escreve.</p>
        <p>Se você falar de forma confusa, ela responde de forma confusa. Se você falar de forma clara e organizada, ela responde muito melhor.</p>
        <p><strong>Engenharia de Prompt</strong> é a arte de escrever mensagens claras para a IA.</p>
        
        <div class="destaque">
          Prompt = a mensagem / pergunta / ordem que você digita para a IA.
        </div>
      </div>

      <div class="card">
        <h3>Por que isso é importante?</h3>
        <p>Porque modelos pequenos (os que rodam no celular) são mais “burros” que o ChatGPT. Eles precisam de instruções bem claras para funcionar bem.</p>
        <p>Se você aprender a escrever prompts bons agora, tudo que você criar no futuro vai funcionar muito melhor.</p>
      </div>

      <div class="card">
        <h3>A estrutura mágica de um bom prompt</h3>
        <p>Quase sempre use esta estrutura:</p>
        
        <div class="code-block">Você é um [papel].
Sua tarefa é: [o que ele deve fazer].
Responda de forma [como deve responder].
Contexto: [informações extras se precisar].</div>

        <p><strong>Exemplo real:</strong></p>
        <div class="code-block">Você é um professor paciente de programação.
Sua tarefa é: explicar o que é uma variável de forma super simples.
Responda de forma curta e use uma analogia do dia a dia.
Contexto: a pessoa nunca programou na vida.</div>
      </div>

      <div class="card">
        <h3>Analogia para nunca esquecer</h3>
        <p>Pense na IA como um funcionário novo na empresa.</p>
        <ul>
          <li>Se você disser só “faz um relatório”, ele vai ficar perdido.</li>
          <li>Se você disser “Você é o analista de vendas. Faça um relatório de vendas do mês passado em 5 tópicos. Use linguagem simples.”, ele entrega exatamente o que você quer.</li>
        </ul>
      </div>

      <div class="destaque sucesso">
        <strong>Resumo desta aula:</strong><br>
        Prompt bom = papel + tarefa + forma de responder + contexto.
      </div>

      <div class="aula-nav">
        <button class="btn btn-secondary" onclick="navegar('modulo1')">← Voltar</button>
        <button class="btn" onclick="marcarConcluida('aula-1-1'); navegar('aula-1-2')">Próxima aula →</button>
      </div>
    `
  },

  "aula-1-2": {
    title: "Aula 1.2",
    html: `
      <div class="aula-header">
        <div class="passo">Módulo 1 · Aula 1.2</div>
        <h2>Instalando a IA no seu celular</h2>
      </div>

      <div class="card">
        <h3>O que vamos fazer nesta aula?</h3>
        <p>Vamos instalar um aplicativo gratuito chamado <strong>PocketPal AI</strong>. Esse app permite que uma Inteligência Artificial rode <strong>dentro do seu celular</strong>, sem precisar de internet.</p>
        <p>É como ter um ChatGPT particular que funciona mesmo no modo avião.</p>
      </div>

      <div class="card">
        <h3>Passo 1 – Instalar o aplicativo</h3>
        <ol>
          <li>Abra a <strong>Play Store</strong> no seu Realme C85.</li>
          <li>Na busca, digite exatamente: <strong>PocketPal AI</strong></li>
          <li>Toque no aplicativo que aparecer (o nome é PocketPal AI).</li>
          <li>Toque em <strong>Instalar</strong>.</li>
          <li>Espere terminar a instalação.</li>
          <li>Toque em <strong>Abrir</strong>.</li>
        </ol>
        <div class="destaque aviso">
          Se não aparecer na Play Store, me avise na seção de Dúvidas que eu te ensino outro caminho.
        </div>
      </div>

      <div class="card">
        <h3>Passo 2 – Baixar o primeiro modelo de IA</h3>
        <p>O aplicativo é só a “casinha”. Agora precisamos colocar o “cérebro” (o modelo) dentro dele.</p>
        <ol>
          <li>Abra o PocketPal AI.</li>
          <li>Procure um botão ou ícone de <strong>Modelos</strong> ou <strong>Models</strong> (geralmente parece um cérebro ou uma lista).</li>
          <li>Toque em baixar / download.</li>
          <li>Escolha um destes modelos (comece pelo primeiro):</li>
        </ol>
        
        <div class="destaque">
          <strong>Recomendado para você (8 GB de RAM):</strong><br>
          • Qwen2.5-3B (versão Q4 ou Q4_K_M)<br>
          • Ou Llama-3.2-3B (Q4)<br>
          • Ou Gemma-2-2B (Q4)
        </div>

        <p>O download pode demorar vários minutos porque o arquivo é grande (1 a 2 GB). Use Wi-Fi.</p>
      </div>

      <div class="card">
        <h3>Passo 3 – Testar se está offline</h3>
        <ol>
          <li>Ative o <strong>Modo Avião</strong> no celular.</li>
          <li>Abra o PocketPal.</li>
          <li>Selecione o modelo que você baixou.</li>
          <li>Digite: <em>Olá, você está funcionando sem internet?</em></li>
          <li>Espere a resposta.</li>
        </ol>
        <p>Se ele responder, <strong>parabéns!</strong> Você tem uma IA rodando 100% offline no seu celular.</p>
      </div>

      <div class="destaque sucesso">
        <strong>Resumo:</strong> PocketPal = a casinha. Modelo = o cérebro. Juntos eles formam sua IA offline.
      </div>

      <div class="aula-nav">
        <button class="btn btn-secondary" onclick="navegar('aula-1-1')">← Aula anterior</button>
        <button class="btn" onclick="marcarConcluida('aula-1-2'); navegar('aula-1-3')">Próxima aula →</button>
      </div>
    `
  },

  "aula-1-3": {
    title: "Aula 1.3",
    html: `
      <div class="aula-header">
        <div class="passo">Módulo 1 · Aula 1.3</div>
        <h2>Praticando prompts de verdade</h2>
      </div>

      <div class="card">
        <h3>Agora é hora de praticar</h3>
        <p>Abra o PocketPal (com o modelo já baixado) e teste os prompts abaixo um por um.</p>
        <p>Copie e cole exatamente como está. Depois observe a resposta.</p>
      </div>

      <div class="card">
        <h3>Exercício 1 – Resumo simples</h3>
        <div class="code-block">Você é um assistente que resume textos de forma clara.
Resuma o texto abaixo em no máximo 3 frases curtas:

A inteligência artificial está mudando o mundo. Ela já é usada em celulares, carros, hospitais e empresas. No futuro, quase todas as profissões vão usar alguma forma de IA.</div>
        <p>Depois de colar, veja se a resposta ficou curta e clara.</p>
      </div>

      <div class="card">
        <h3>Exercício 2 – Plano de estudos</h3>
        <div class="code-block">Você é um planejador de estudos paciente.
Crie um plano de 5 dias para uma pessoa que nunca programou na vida aprender o básico de Python.
Cada dia deve ter só 1 tarefa simples.
Responda apenas com a lista dos 5 dias.</div>
      </div>

      <div class="card">
        <h3>Exercício 3 – Você cria o prompt</h3>
        <p>Agora é sua vez. Crie um prompt usando a estrutura:</p>
        <div class="code-block">Você é um [papel].
Sua tarefa é: [tarefa].
Responda de forma [estilo].</div>
        <p>Exemplos de ideias: explicar o que é Wi-Fi, criar uma lista de compras, dar dicas de organização.</p>
      </div>

      <div class="destaque">
        <strong>Dica importante:</strong> Modelos pequenos às vezes inventam coisas. Se a resposta parecer estranha, peça: “Responda de forma mais simples e curta”.
      </div>

      <div class="aula-nav">
        <button class="btn btn-secondary" onclick="navegar('aula-1-2')">← Aula anterior</button>
        <button class="btn" onclick="marcarConcluida('aula-1-3'); navegar('aula-1-4')">Próxima aula →</button>
      </div>
    `
  },

  "aula-1-4": {
    title: "Aula 1.4",
    html: `
      <div class="aula-header">
        <div class="passo">Módulo 1 · Aula 1.4</div>
        <h2>Seu primeiro mini-agente</h2>
      </div>

      <div class="card">
        <h3>O que é um mini-agente?</h3>
        <p>É um prompt bem feito que transforma a IA em um “especialista” em uma tarefa específica.</p>
        <p>Em vez de toda vez explicar tudo, você cria um prompt pronto e só muda a pergunta final.</p>
      </div>

      <div class="card">
        <h3>Exemplo de mini-agente pronto</h3>
        <p>Copie este prompt inteiro e cole no PocketPal:</p>
        <div class="code-block">Você é o "Professor Zero", um professor extremamente paciente que ensina tecnologia para quem não sabe nada.

Regras:
- Use linguagem simples como se estivesse falando com uma criança de 10 anos
- Use analogias do dia a dia
- Nunca use termos técnicos sem explicar
- Responda sempre em português do Brasil
- Seja encorajador

Agora responda a pergunta do aluno:</div>
        <p>Depois do prompt acima, escreva qualquer dúvida, por exemplo: “O que é um aplicativo?”</p>
      </div>

      <div class="card">
        <h3>Exercício final do Módulo 1</h3>
        <p>Crie o seu próprio mini-agente. Escolha um tema (ex: culinária, organização, exercícios físicos, estudos) e monte o prompt completo.</p>
        <p>Teste no PocketPal e veja se ele se comporta como o especialista que você criou.</p>
      </div>

      <div class="destaque sucesso">
        <strong>Parabéns!</strong> Você terminou o Módulo 1.<br>
        Agora você já sabe: o que é prompt, como rodar IA offline e como criar um mini-agente.
      </div>

      <div class="aula-nav">
        <button class="btn btn-secondary" onclick="navegar('aula-1-3')">← Aula anterior</button>
        <button class="btn" onclick="marcarConcluida('aula-1-4'); navegar('modulo2')">Ir para o Módulo 2 →</button>
      </div>
    `
  },

  modulo2: {
    title: "Módulo 2",
    html: `
      <div class="card">
        <h2>Módulo 2 – Python Essencial para IA</h2>
        <p>Este módulo ainda está sendo preparado com o mesmo cuidado extremo de simplicidade.</p>
        <div class="destaque aviso">
          Em breve você terá aqui aulas sobre:
          <ul>
            <li>O que é Python (explicado como se fosse a primeira vez)</li>
            <li>Como instalar no celular com Termux</li>
            <li>Variáveis, listas e funções do jeito mais simples possível</li>
            <li>Como conversar com a IA usando código</li>
          </ul>
        </div>
        <button class="btn btn-secondary" onclick="navegar('home')">Voltar ao Início</button>
      </div>
    `
  },

  modulo3: {
    title: "Módulo 3",
    html: `
      <div class="card">
        <h2>Módulo 3 – Sistemas Multiagentes</h2>
        <p>Conteúdo em preparação. Aqui você vai aprender a criar vários agentes que trabalham juntos.</p>
        <button class="btn btn-secondary" onclick="navegar('home')">Voltar ao Início</button>
      </div>
    `
  },

  modulo4: {
    title: "Módulo 4",
    html: `
      <div class="card">
        <h2>Módulo 4 – Arquiteturas Avançadas</h2>
        <p>Conteúdo em preparação. Aqui entram os grafos e a intervenção humana.</p>
        <button class="btn btn-secondary" onclick="navegar('home')">Voltar ao Início</button>
      </div>
    `
  },

  duvidas: {
    title: "Dúvidas",
    html: `
      <div class="card">
        <h2>Tirar Dúvidas</h2>
        <p>Aqui estão as dúvidas mais comuns. Toque na pergunta para ver a resposta.</p>
      </div>

      <div class="card">
        <h3 onclick="this.nextElementSibling.classList.toggle('hidden')" style="cursor:pointer">
          ▶ O PocketPal não aparece na Play Store
        </h3>
        <div class="hidden">
          <p>Às vezes o nome muda um pouco. Tente pesquisar só “PocketPal”. Se não achar, me avise que eu te passo o link do APK oficial.</p>
        </div>
      </div>

      <div class="card">
        <h3 onclick="this.nextElementSibling.classList.toggle('hidden')" style="cursor:pointer">
          ▶ O modelo está muito lento
        </h3>
        <div class="hidden">
          <p>Isso é normal em celulares de entrada. Tente um modelo menor (1B ou 2B). Feche outros aplicativos. Evite usar enquanto carrega a bateria.</p>
        </div>
      </div>

      <div class="card">
        <h3 onclick="this.nextElementSibling.classList.toggle('hidden')" style="cursor:pointer">
          ▶ A IA inventa respostas erradas
        </h3>
        <div class="hidden">
          <p>Modelos pequenos fazem isso. Sempre peça: “Responda só com base no que você tem certeza” ou “Se não souber, diga que não sabe”.</p>
        </div>
      </div>

      <div class="card">
        <h3 onclick="this.nextElementSibling.classList.toggle('hidden')" style="cursor:pointer">
          ▶ Não entendi o que é prompt
        </h3>
        <div class="hidden">
          <p>Prompt é simplesmente a mensagem que você digita para a IA. É como a pergunta ou a ordem que você dá.</p>
        </div>
      </div>

      <div class="card">
        <h3 onclick="this.nextElementSibling.classList.toggle('hidden')" style="cursor:pointer">
          ▶ Quero mais aulas agora
        </h3>
        <div class="hidden">
          <p>O Módulo 1 está completo. Os próximos módulos serão adicionados em atualizações. Continue praticando os prompts enquanto isso.</p>
        </div>
      </div>
    `
  },

  playground: {
    title: "Playground",
    html: `
      <div class="card">
        <h2>Playground de Prompts</h2>
        <p>Aqui você pode escrever e guardar seus prompts favoritos. Eles ficam salvos neste celular.</p>
        
        <label>Escreva seu prompt:</label>
        <textarea id="prompt-input" class="prompt-box" placeholder="Você é um..."></textarea>
        
        <button class="btn" onclick="salvarPrompt()">Salvar este prompt</button>
        <button class="btn btn-secondary" onclick="limparPrompt()">Limpar</button>
        
        <h3 style="margin-top:24px">Seus prompts salvos</h3>
        <div id="lista-prompts"></div>
      </div>
    `
  },

  sobre: {
    title: "Sobre",
    html: `
      <div class="card">
        <h2>Sobre este curso</h2>
        <p>Este aplicativo foi criado especialmente para quem quer aprender Agentes de Inteligência Artificial começando do zero absoluto e rodando tudo offline no celular.</p>
        <p>Todo o conteúdo foi escrito de forma extremamente simples, com analogias e passos bem detalhados.</p>
        <p>Versão 1.0 – Foco no Módulo 1 completo + estrutura dos demais módulos.</p>
      </div>
    `
  }
};
